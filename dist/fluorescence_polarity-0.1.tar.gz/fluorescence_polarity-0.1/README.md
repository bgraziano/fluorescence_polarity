# fluorescence_polarity
 Methods for quantifying polarity of fluorescence markers
